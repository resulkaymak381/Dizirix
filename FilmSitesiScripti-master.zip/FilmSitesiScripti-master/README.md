# FilmSitesiScripti
Html ve CSS Film Sitesi Scripti

Sitenin tasarımı Balsamiq Wireframes programından yapıldı proje dosyası dosyalarda mevcut.

DEMO ---->  http://makine.cf/
